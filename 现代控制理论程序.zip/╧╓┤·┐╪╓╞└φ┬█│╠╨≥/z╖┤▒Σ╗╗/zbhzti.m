clear all;
close all;
clc;
syms n k z;
f=z/(z-2)/(z-4)/(z-1)  ;      
fanz=iztrans(f)%���任

